# Aula de Programação para Dispositivos Móveis (fevereiro/2026)

🔎 Este repositório contém os códigos/atividades desenvolvidas nas aulas de Programação para Dispositivos Móveis sobre Button e Text View.

## Instalação

📌 Instale o projeto com npm:

```bash
  npm install ButtonTextView
  cd ButtonTextView
```
    
## Autores

- [@Natali](https://github.com/nouveauromance)

🔗 Aula por Vinícius Heltai Pacheco

📍 Fatec Diadema Luigi Papaiz 
